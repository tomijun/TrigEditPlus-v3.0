/*
** $Id: linit.c $
** Initialization of libraries for lua.c and other clients
** See Copyright Notice in lua.h
*/


#define linit_c
#define LUA_LIB

/*
** If you embed Lua in your program and need to open the standard
** libraries, call luaL_openlibs in your program. If you need a
** different set of libraries, copy this file to your project and edit
** it to suit your needs.
**
** You can also *preload* libraries, so that a later 'require' can
** open the library, which is already linked to the application.
** For that, do the following code:
**
**  luaL_getsubtable(L, LUA_REGISTRYINDEX, LUA_PRELOAD_TABLE);
**  lua_pushcfunction(L, luaopen_modname);
**  lua_setfield(L, -2, modname);
**  lua_pop(L, 1);  // remove PRELOAD table
*/

#include "lprefix.h"


#include <stddef.h>

#include "lua.h"

#include "lualib.h"
#include "lauxlib.h"

int luaL_checkinteger_Fix(lua_State* L, int arg) {
    int isnum;
    int ret = lua_tointegerx(L, arg, &isnum);
    if (!isnum) {
        ret = (lua_Integer)lua_tonumberx(L, arg, &isnum);
    }
    return ret;
}

typedef lua_Unsigned b_uint;

/* number of bits to consider in a number */
#if !defined(LUA_NBITS)
#define LUA_NBITS	32
#endif

#define ALLONES		(~(((~(lua_Unsigned)0) << (LUA_NBITS - 1)) << 1))

/* macro to trim extra bits */
#define trim(x)		((x) & ALLONES)


/* builds a number with 'n' ones (1 <= n <= LUA_NBITS) */
#define mask(n)		(~((ALLONES << 1) << ((n) - 1)))

static b_uint andaux(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = ~(b_uint)0;
    for (i = 1; i <= n; i++)
        r &= (b_uint)luaL_checkinteger_Fix(L, i);
    return trim(r);
}

static int b_and(lua_State* L) {
    b_uint r = andaux(L);
    lua_pushinteger(L, r);
    return 1;
}

static int b_test(lua_State* L) {
    b_uint r = andaux(L);
    lua_pushboolean(L, r != 0);
    return 1;
}

static int b_or(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = 0;
    for (i = 1; i <= n; i++)
        r |= (b_uint)luaL_checkinteger_Fix(L, i);
    lua_pushinteger(L, trim(r));
    return 1;
}

static int b_xor(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = 0;
    for (i = 1; i <= n; i++)
        r ^= (b_uint)luaL_checkinteger_Fix(L, i);
    lua_pushinteger(L, trim(r));
    return 1;
}


static int b_not(lua_State* L) {
    b_uint r = ~(b_uint)luaL_checkinteger_Fix(L, 1);
    lua_pushinteger(L, trim(r));
    return 1;
}


static int b_shift(lua_State* L, b_uint r, int i) {
    if (i < 0) {  /* shift right? */
        i = -i;
        r = trim(r);
        if (i >= LUA_NBITS) r = 0;
        else r >>= i;
    }
    else {  /* shift left */
        if (i >= LUA_NBITS) r = 0;
        else r <<= i;
        r = trim(r);
    }
    lua_pushinteger(L, r);
    return 1;
}


static int b_lshift(lua_State* L) {
    return b_shift(L, (b_uint)luaL_checkinteger_Fix(L, 1), luaL_checkinteger_Fix(L, 2));
}


static int b_rshift(lua_State* L) {
    return b_shift(L, (b_uint)luaL_checkinteger_Fix(L, 1), -luaL_checkinteger_Fix(L, 2));
}


static int b_arshift(lua_State* L) {
    b_uint r = (b_uint)luaL_checkinteger_Fix(L, 1);
    int i = luaL_checkinteger_Fix(L, 2);
    if (i < 0 || !(r & ((b_uint)1 << (LUA_NBITS - 1))))
        return b_shift(L, r, -i);
    else {  /* arithmetic shift for 'negative' number */
        if (i >= LUA_NBITS) r = ALLONES;
        else
            r = trim((r >> i) | ~(~(b_uint)0 >> i));  /* add signal bit */
        lua_pushinteger(L, r);
        return 1;
    }
}


static int b_rot(lua_State* L, int i) {
    b_uint r = (b_uint)luaL_checkinteger_Fix(L, 1);
    i &= (LUA_NBITS - 1);  /* i = i % NBITS */
    r = trim(r);
    if (i != 0)  /* avoid undefined shift of LUA_NBITS when i == 0 */
        r = (r << i) | (r >> (LUA_NBITS - i));
    lua_pushinteger(L, trim(r));
    return 1;
}


static int b_lrot(lua_State* L) {
    return b_rot(L, luaL_checkinteger_Fix(L, 2));
}


static int b_rrot(lua_State* L) {
    return b_rot(L, -luaL_checkinteger_Fix(L, 2));
}



/*
** get field and width arguments for field-manipulation functions,
** checking whether they are valid.
** ('luaL_error' called without 'return' to avoid later warnings about
** 'width' being used uninitialized.)
*/
static int fieldargs(lua_State* L, int farg, int* width) {
    int f = luaL_checkinteger_Fix(L, farg);
    int w = luaL_optinteger(L, farg + 1, 1);
    luaL_argcheck(L, 0 <= f, farg, "field cannot be negative");
    luaL_argcheck(L, 0 < w, farg + 1, "width must be positive");
    if (f + w > LUA_NBITS)
        luaL_error(L, "trying to access non-existent bits");
    *width = w;
    return f;
}


static int b_extract(lua_State* L) {
    int w;
    b_uint r = (b_uint)luaL_checkinteger_Fix(L, 1);
    int f = fieldargs(L, 2, &w);
    r = (r >> f) & mask(w);
    lua_pushinteger(L, r);
    return 1;
}


static int b_replace(lua_State* L) {
    int w;
    b_uint r = (b_uint)luaL_checkinteger_Fix(L, 1);
    b_uint v = (b_uint)luaL_checkinteger_Fix(L, 2);
    int f = fieldargs(L, 3, &w);
    int m = mask(w);
    v &= m;  /* erase bits outside given width */
    r = (r & ~(m << f)) | (v << f);
    lua_pushinteger(L, r);
    return 1;
}


static const luaL_Reg bitlib[] = {
    {"arshift", b_arshift},
    {"band", b_and},
    {"bnot", b_not},
    {"bor", b_or},
    {"bxor", b_xor},
    {"btest", b_test},
    {"extract", b_extract},
    {"lrotate", b_lrot},
    {"lshift", b_lshift},
    {"replace", b_replace},
    {"rrotate", b_rrot},
    {"rshift", b_rshift},
    {NULL, NULL}
};

int luaopen_bit32(lua_State* L) {
    luaL_newlib(L, bitlib);
    return 1;
}


//------------------------------------------------------------------------------------
b_uint luaL_checkinteger_EX(lua_State* L, int arg) {
    int isnum;
    b_uint ret = lua_tointegerx(L, arg, &isnum);
    if (!isnum) {
        ret = (lua_Integer)lua_tonumberx(L, arg, &isnum);
    }
    return ret;
}

/* number of bits to consider in a number */
#if !defined(LUA_EXBITS)
#define LUA_EXBITS	64
#endif

#define ALLONESEX	(~(((~(lua_Unsigned)0) << (LUA_EXBITS - 1)) << 1))

/* macro to trim extra bits */
#define trimEX(x)	((x) & ALLONESEX)


/* builds a number with 'n' ones (1 <= n <= LUA_EXBITS) */
#define maskEX(n)		(~((ALLONESEX << 1) << ((n) - 1)))

static b_uint exandaux(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = ~(b_uint)0;
    for (i = 1; i <= n; i++)
        r &= (b_uint)luaL_checkinteger_EX(L, i);
    return trimEX(r);
}

static int ex_and(lua_State* L) {
    b_uint r = exandaux(L);
    lua_pushinteger(L, r);
    return 1;
}

static int ex_test(lua_State* L) {
    b_uint r = exandaux(L);
    lua_pushboolean(L, r != 0);
    return 1;
}

static int ex_or(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = 0;
    for (i = 1; i <= n; i++)
        r |= (b_uint)luaL_checkinteger_EX(L, i);
    lua_pushinteger(L, trimEX(r));
    return 1;
}

static int ex_xor(lua_State* L) {
    int i, n = lua_gettop(L);
    b_uint r = 0;
    for (i = 1; i <= n; i++)
        r ^= (b_uint)luaL_checkinteger_EX(L, i);
    lua_pushinteger(L, trimEX(r));
    return 1;
}


static int ex_not(lua_State* L) {
    b_uint r = ~(b_uint)luaL_checkinteger_EX(L, 1);
    lua_pushinteger(L, trimEX(r));
    return 1;
}


static int ex_shift(lua_State* L, b_uint r, lua_Integer i) {
    if (i < 0) {  /* shift right? */
        i = -i;
        r = trimEX(r);
        if (i >= LUA_EXBITS) r = 0;
        else r >>= i;
    }
    else {  /* shift left */
        if (i >= LUA_EXBITS) r = 0;
        else r <<= i;
        r = trimEX(r);
    }
    lua_pushinteger(L, r);
    return 1;
}


static int ex_lshift(lua_State* L) {
    return ex_shift(L, (b_uint)luaL_checkinteger_EX(L, 1), luaL_checkinteger_EX(L, 2));
}


static int ex_rshift(lua_State* L) {
    return ex_shift(L, (b_uint)luaL_checkinteger_EX(L, 1), -luaL_checkinteger_EX(L, 2));
}


static int ex_arshift(lua_State* L) {
    b_uint r = (b_uint)luaL_checkinteger_EX(L, 1);
    lua_Integer i = luaL_checkinteger_EX(L, 2);
    if (i < 0 || !(r & ((b_uint)1 << (LUA_EXBITS - 1))))
        return ex_shift(L, r, -i);
    else {  /* arithmetic shift for 'negative' number */
        if (i >= LUA_EXBITS) r = ALLONESEX;
        else
            r = trimEX((r >> i) | ~(~(b_uint)0 >> i));  /* add signal bit */
        lua_pushinteger(L, r);
        return 1;
    }
}


static int ex_rot(lua_State* L, lua_Integer i) {
    b_uint r = (b_uint)luaL_checkinteger_EX(L, 1);
    i &= (LUA_EXBITS - 1);  /* i = i % NBITS */
    r = trimEX(r);
    if (i != 0)  /* avoid undefined shift of LUA_EXBITS when i == 0 */
        r = (r << i) | (r >> (LUA_EXBITS - i));
    lua_pushinteger(L, trimEX(r));
    return 1;
}


static int ex_lrot(lua_State* L) {
    return ex_rot(L, luaL_checkinteger_EX(L, 2));
}


static int ex_rrot(lua_State* L) {
    return ex_rot(L, -luaL_checkinteger_EX(L, 2));
}



/*
** get field and width arguments for field-manipulation functions,
** checking whether they are valid.
** ('luaL_error' called without 'return' to avoid later warnings about
** 'width' being used uninitialized.)
*/
static b_uint exfieldargs(lua_State* L, int farg, lua_Integer* width) {
    lua_Integer f = luaL_checkinteger_EX(L, farg);
    lua_Integer w = luaL_optinteger(L, farg + 1, 1);
    luaL_argcheck(L, 0 <= f, farg, "field cannot be negative");
    luaL_argcheck(L, 0 < w, farg + 1, "width must be positive");
    if (f + w > LUA_EXBITS)
        luaL_error(L, "trying to access non-existent bits");
    *width = w;
    return f;
}


static int ex_extract(lua_State* L) {
    b_uint w;
    b_uint r = (b_uint)luaL_checkinteger_EX(L, 1);
    b_uint f = exfieldargs(L, 2, &w);
    r = (r >> f) & maskEX(w);
    lua_pushinteger(L, r);
    return 1;
}


static int ex_replace(lua_State* L) {
    b_uint w;
    b_uint r = (b_uint)luaL_checkinteger_EX(L, 1);
    b_uint v = (b_uint)luaL_checkinteger_EX(L, 2);
    b_uint f = exfieldargs(L, 3, &w);
    b_uint m = maskEX(w);
    v &= m;  /* erase bits outside given width */
    r = (r & ~(m << f)) | (v << f);
    lua_pushinteger(L, r);
    return 1;
}




static const luaL_Reg bitlib64[] = {
    {"arshift", ex_arshift},
    {"band", ex_and},
    {"bnot", ex_not},
    {"bor", ex_or},
    {"bxor", ex_xor},
    {"btest", ex_test},
    {"extract", ex_extract},
    {"lrotate", ex_lrot},
    {"lshift", ex_lshift},
    {"replace", ex_replace},
    {"rrotate", ex_rrot},
    {"rshift", ex_rshift},
    {NULL, NULL}
};

int luaopen_bit64(lua_State* L) {
    luaL_newlib(L, bitlib64);
    return 1;
}



//-----------------------------------------------------------

/*
** these libs are loaded by lua.c and are readily available to any Lua
** program
*/
static const luaL_Reg loadedlibs[] = {
  {LUA_GNAME, luaopen_base},
  {LUA_LOADLIBNAME, luaopen_package},
  {LUA_COLIBNAME, luaopen_coroutine},
  {LUA_TABLIBNAME, luaopen_table},
  {LUA_IOLIBNAME, luaopen_io},
  {LUA_OSLIBNAME, luaopen_os},
  {LUA_STRLIBNAME, luaopen_string},
  {LUA_BITLIBNAME, luaopen_bit32},
  {LUA_BITLIBNAME64, luaopen_bit64},
  {LUA_MATHLIBNAME, luaopen_math},
  {LUA_UTF8LIBNAME, luaopen_utf8},
  {LUA_DBLIBNAME, luaopen_debug},
  {NULL, NULL}
};


LUALIB_API void luaL_openlibs (lua_State *L) {
  const luaL_Reg *lib;
  /* "require" functions from 'loadedlibs' and set results to global table */
  for (lib = loadedlibs; lib->func; lib++) {
    luaL_requiref(L, lib->name, lib->func, 1);
    lua_pop(L, 1);  /* remove lib */
  }
}


