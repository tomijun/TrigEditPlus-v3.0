﻿/*
 * Copyright (c) 2014 trgk(phu54321@naver.com)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "TriggerEditor.h"
#include "MapNamespace.h"
#include "../resource.h"
#include "../version.h"
#include <CommCtrl.h>
#include <Windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <cstring>
struct SearchQuery
{
	std::string searchFor;
	std::string replaceTo;
	int mode; // 0:find, 1:findall 2:replace 3:replaceall
	unsigned int searchFlag;
};


void ApplyAutocomplete(TriggerEditor* te);
void ProcessSearchMessage(HWND hTrigDlg, TriggerEditor* te, SearchQuery* q, int editlen);

TriggerEditor::TriggerEditor() : hTrigDlg(NULL), hScintilla(NULL),
	hFindDlg(NULL), _textedited(false) {}
TriggerEditor::~TriggerEditor() {}

HMENU hMenu;
HMENU hEdit;
HMENU hCtrig;
DWORD Uprev;
char path[MAX_PATH];
char* lastslash;
std::string Name;
std::string TMPName;
std::string LoaderName;
int TriggerEditor::RunEditor(HWND hMain, TriggerEditor_Arg& arg) {
	_editordata = &arg;
	_namespace = new MapNamespace(arg);

	currentft = FIELDTYPE_NONE;

	GetModuleFileName(NULL, path, MAX_PATH);
	lastslash = strrchr(path, '\\');
	*lastslash = '\0';
	TMPName = path;
	TMPName += "\\SCMD2TMP.chk";
	LoaderName = path;
	LoaderName += "\\SCMD2Loader.lua";

	char Uflag, Cflag;
	FILE* ftmp;
	fopen_s(&ftmp, TMPName.data(), "rb");
	if (ftmp == NULL)
	{
		fopen_s(&ftmp, TMPName.data(), "wb");
		Uflag = 1;
		fwrite(&Uflag, 1, 1, ftmp);
		Cflag = 0;
		fwrite(&Cflag, 1, 1, ftmp);
	}
	else
	{
		fread(&Uflag, 1, 1, ftmp);
		fread(&Cflag, 1, 1, ftmp);
		fclose(ftmp);

		fopen_s(&ftmp, TMPName.data(), "wb");
		fwrite(&Uflag, 1, 1, ftmp);
		fwrite(&Cflag, 1, 1, ftmp);
	}
	fclose(ftmp);

	hMenu = LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MAINMENU));
	HACCEL hAccel = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDR_ACCELERATOR));

	hEdit = GetSubMenu(hMenu, 1);
	if (Uflag == 0)
		CheckMenuItem(hEdit, 5, MF_BYPOSITION | MF_CHECKED);
	else
		CheckMenuItem(hEdit, 5, MF_BYPOSITION | MF_UNCHECKED);

	hCtrig = GetSubMenu(hMenu, 4);
	if (Cflag == 0)
	{
		CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_UNCHECKED);
		CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_UNCHECKED);
	}
	else if (Cflag == 1)
	{
		CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_CHECKED);
		CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_UNCHECKED);
	}
	else if (Cflag == 2)
	{
		CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_UNCHECKED);
		CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_CHECKED);
		/*
		EnableMenuItem(hEdit, 5, MF_BYPOSITION | MF_GRAYED);

		FILE* flua;
		fopen_s(&flua, LoaderName.data(), "rb");
		if (flua == NULL)
		{
			fopen_s(&flua, LoaderName.data(), "wb");
			HRSRC ETResource = ::FindResource(hInstance, MAKEINTRESOURCE(IDR_LOADER), RT_RCDATA);
			HGLOBAL ETResourceData = ::LoadResource(hInstance, ETResource);
			void* ETptr = ::LockResource(ETResourceData);
			fwrite((char*)ETptr, 1, strlen((char*)ETptr), flua);
		}
		fclose(flua);
		*/
	}

	TriggerEditor *this2 = this;
	hTrigDlg = CreateWindow(
		"TrigEditPlusDlg",
		"TrigEditPlus " VERSION,
		WS_OVERLAPPEDWINDOW | WS_MAXIMIZE,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		800,
		600,
		hMain,
		hMenu,
		hInstance,
		this2
		);
	if ((GetAsyncKeyState(VK_SHIFT)&0x8000) == 0x8000)
		SetEditorText(DecodeTriggers(arg.Triggers,0));
	else
		SetEditorText(DecodeTriggers(arg.Triggers,1));
	SendSciMessage(SCI_SETSAVEPOINT, 0, 0);
	SendSciMessage(SCI_EMPTYUNDOBUFFER, 0, 0);
	SendSciMessage(SCI_FOLDALL, SC_FOLDACTION_CONTRACT, 0);
	_textedited = false;

	ShowWindow(hTrigDlg, SW_SHOW);	

	MSG msg;
	while (hTrigDlg && GetMessage(&msg, NULL, NULL, NULL)) {
		if (!IsWindow(hFindDlg) || !IsDialogMessage(hFindDlg, &msg)) {
			if (!TranslateAccelerator(hTrigDlg, hAccel, &msg)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}

	delete _namespace;
	DestroyMenu(hMenu);
	DestroyAcceleratorTable(hAccel);
	return 0;
}






void TriggerEditor::SetEditorText(const std::string& str) {
	SendMessage(hScintilla, SCI_SETTEXT, 0, (LPARAM)str.c_str());
}

std::string TriggerEditor::GetEditorText() const {
	int sLen = SendMessage(hScintilla, SCI_GETTEXTLENGTH, 0, 0);
	char* s = new char[sLen + 1];
	SendMessage(hScintilla, SCI_GETTEXT, sLen + 1, (LPARAM)s);
	std::string ret = std::string(s, s+sLen);
	delete[] s;
	return ret;
}


void TriggerEditor::ClearErrors() {
	_errlist.clear();
	_errlist << "Compile failed because of the following reason:\r\n";
}


void TriggerEditor::PrintErrorMessage(const std::string& msg) {
	_errlist << msg.c_str() << "\r\n";
}


int TriggerEditor::SendSciMessage(int msg, WPARAM wParam, LPARAM lParam) {
	return _pSciMsg(_pSciWndData, msg, wParam, lParam);
}




char szFindText[4096];
char szReplaceText[4096];
static FINDREPLACE fr;

void Editor_CharAdded(SCNotification* ne, TriggerEditor* te);
void ApplyEditorStyle(TriggerEditor* te);
void ApplyAutocomplete(TriggerEditor* te);

const int ScintillaID = 1000;
const int TabID = 1001;
const int ElmnTableID = 1002;
const int StatusBarID = 1003;

HBITMAP hBitmap = NULL;
LRESULT CALLBACK TrigEditPicProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	switch (msg) {
	case WM_CREATE:
	{
		HICON hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
		SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
		hBitmap = (HBITMAP)LoadImage(hInstance, MAKEINTRESOURCE(IDR_RCICON), IMAGE_BITMAP, 0, 0, 0);
	}
		break;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW + 1));
		BITMAP          bitmap;
		HDC             hdcMem;
		HGDIOBJ         oldBitmap;

		hdcMem = CreateCompatibleDC(hdc);
		oldBitmap = SelectObject(hdcMem, hBitmap);

		GetObject(hBitmap, sizeof(bitmap), &bitmap);
		BitBlt(hdc, 0, 0, bitmap.bmWidth, bitmap.bmHeight, hdcMem, 0, 0, SRCCOPY);

		SelectObject(hdcMem, oldBitmap);
		DeleteDC(hdcMem);

		EndPaint(hWnd, &ps);

		return 0;
	}
	case WM_DESTROY:
	{
		DeleteObject(hBitmap);
		PostQuitMessage(0);
		return 0;
	}
	}

	return DefWindowProc(hWnd, msg, wParam, lParam);
}

void PicFunc()
{
	//Window class name
	const char windowName[] = "Pic Class";

	//Set up window class
	WNDCLASS wnd = { 0 };
	wnd.lpfnWndProc = TrigEditPicProc;
	wnd.hInstance = hInstance;
	wnd.lpszClassName = windowName;

	//Register window class
	RegisterClass(&wnd);

	//Create window
	//! This returns NULL
	HWND hWnd = CreateWindowEx(
		0,
		windowName,
		"< Black/Archive >",
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		1008,
		756,
		NULL,
		NULL,
		hInstance,
		NULL
	);

	//Show the window
	ShowWindow(hWnd,5);

	//Main message loop
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

void utf16to8(void* ptr, char* in, std::string& out)
{
	char* ETptr = ((char*)ptr);
	out = "";
	int remain = strlen(in), pos = 0, size = 0;
	BYTE* inptr = (BYTE*)in;
	while (remain > 0 && size < (4096-3))
	{
		if (inptr[pos] >= 0x80 && remain >= 2) // 2bytes
		{
			int loc = ((inptr[pos] << 8) + inptr[pos + 1] - 0x8141) << 2;
			if (loc >= 0x1F2F8 || loc < 0)
				loc = 0x9260;
			
			if (ETptr[loc + 2] == 0x0) // 2bytes
			{
				out += ETptr[loc];
				out += ETptr[loc + 1];
				size += 2;
			}
			else // 3bytes
			{
				out += ETptr[loc];
				out += ETptr[loc + 1];
				out += ETptr[loc + 2];
				size += 3;
			}
			pos += 2;
			remain -= 2;
		}
		else // 1byte
		{
			out += inptr[pos];
			pos++;
			remain--;
			size++;
		}
	}
}


FILE* ftmp;
char Uflag, Cflag;
char cbuf[20], dbuf[20];
time_t timer;
struct tm* t;
std::string editortext;
HRSRC ETResource;
HGLOBAL ETResourceData;
void* ETptr;

void ConvertText()
{
	std::string out;
	utf16to8(ETptr, szFindText, out);
	strcpy_s(szFindText, out.data());
	utf16to8(ETptr, szReplaceText, out);
	strcpy_s(szReplaceText, out.data());
}

LRESULT CALLBACK TrigEditDlgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	TriggerEditor* te = reinterpret_cast<TriggerEditor*>(GetWindowLong(hWnd, GWL_USERDATA));
	const static int FindReplaceMsg = RegisterWindowMessage(FINDMSGSTRING);
	 
	switch(msg) {
	case WM_SETFOCUS:
		SetFocus(te->hScintilla);
		break;

	case WM_CREATE:
		{
			EnableWindow(hSCMD2MainWindow, FALSE);
			te = (TriggerEditor*)((CREATESTRUCT*)lParam)->lpCreateParams;
			SetWindowLong(hWnd, GWL_USERDATA, (LONG)te);

			// Init editor window
			te->hScintilla = CreateWindow(
				"Scintilla",
				"",
				WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_CLIPCHILDREN | WS_VSCROLL,
				0,
				0,
				600,
				600,
				hWnd,
				(HMENU)ScintillaID,
				hInstance,
				NULL
				);
			//SendMessage(te->hScintilla, SCI_SETCODEPAGE, SC_CP_UTF8, 0);
			te->_pSciMsg = (SciFnDirect)SendMessage(te->hScintilla, SCI_GETDIRECTFUNCTION, 0, 0);
			te->_pSciWndData = (sptr_t)SendMessage(te->hScintilla, SCI_GETDIRECTPOINTER, 0, 0);
			//te->SendSciMessage(SCI_SETCODEPAGE, SC_CP_UTF8, 0);
			//te->SendSciMessage(SCI_STYLESETCHARACTERSET, , );

			CreateStatusWindow(SBARS_SIZEGRIP | WS_CHILD | WS_VISIBLE, 
				"TrigEditPlus loaded", hWnd, StatusBarID);

			ApplyEditorStyle(te);

			// Autocomplete list
			HWND hElmnTable = CreateWindow("listbox", NULL,
				WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_VSCROLL |
				LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | LBS_SORT,
				600, 0, 200, 600, hWnd, (HMENU)ElmnTableID, hInstance, NULL);

			SendMessage(hElmnTable, WM_SETFONT, (WPARAM)GetStockObject(ANSI_FIXED_FONT), TRUE);
			te->hElmnTable = hElmnTable;

			HICON hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON1));
			SendMessage(hWnd, WM_SETICON, ICON_BIG, (LPARAM)hIcon);

			ETResource = ::FindResource(hInstance, MAKEINTRESOURCE(IDR_ENCODE), RT_RCDATA);
			ETResourceData = ::LoadResource(hInstance, ETResource);
			ETptr = ::LockResource(ETResourceData);
		}
		return 0;

	case WM_SIZE:
		{
			HWND hStatusBar = GetDlgItem(hWnd, StatusBarID);
			SendMessage(hStatusBar, msg, wParam, lParam);

			RECT statusbarRect;
			SendMessage(hStatusBar, SB_GETRECT, 0, (LPARAM)&statusbarRect);
			int statusbar_height = statusbarRect.bottom - statusbarRect.top;


			HWND hElmnTable = te->hElmnTable;

			RECT rt;
			GetClientRect(hWnd, &rt);
			int scrW = rt.right - rt.left;
			int scrH = rt.bottom - rt.top - statusbar_height;

			HDWP hdwp = BeginDeferWindowPos(2);
			DeferWindowPos(hdwp, te->hScintilla, NULL, 0, 0, scrW - 200, scrH, SWP_NOZORDER);
			DeferWindowPos(hdwp, hElmnTable, NULL, scrW - 200, 0, 200, scrH, SWP_NOZORDER);
			EndDeferWindowPos(hdwp);
		}
		return 0;

	case WM_VKEYTOITEM:
		{
			// when user pressed enter while selecting item
			if(LOWORD(lParam) == ElmnTableID && wParam == 13) {
				ApplyAutocomplete(te);
				SetFocus(te->hScintilla);
			}
		}
		return 0;

	case WM_COMMAND:
		{
			switch(LOWORD(wParam)) {
			case IDM_FILE_EXIT:
				PostMessage(hWnd, WM_CLOSE, 0, 0);
				return 0;

			case IDM_FILE_EXPORT:
				GetModuleFileName(NULL, path, MAX_PATH);
				lastslash = strrchr(path, '\\');
				*lastslash = '\0';

				timer = time(NULL);
				t = localtime(&timer);
				Name = path;
				Name += "\\save\\";

				_itoa((t->tm_year + 1900), cbuf, 10);
				strcpy_s(dbuf, cbuf + 2);
				Name += dbuf;
				_itoa((t->tm_mon + 101), cbuf, 10);
				strcpy_s(dbuf, cbuf + 1);
				Name += dbuf;
				_itoa((t->tm_mday + 100), cbuf, 10);
				strcpy_s(dbuf, cbuf + 1);
				Name += dbuf;
				Name += "_";
				_itoa((t->tm_hour + 100), cbuf, 10);
				strcpy_s(dbuf, cbuf + 1);
				Name += dbuf;
				_itoa((t->tm_min + 100), cbuf, 10);
				strcpy_s(dbuf, cbuf + 1);
				Name += dbuf;
				_itoa((t->tm_sec + 100), cbuf, 10);
				strcpy_s(dbuf, cbuf + 1);
				Name += dbuf;
				Name += "_Backup.txt";

				editortext = te->GetEditorText();
				fopen_s(&ftmp, Name.data(), "wb");
				fwrite(editortext.data(), 1, editortext.size(), ftmp);
				fclose(ftmp);

				Name = "Backup file successfully exported.\r\nSaved as " + Name;
				MessageBox(hWnd, Name.data(), "OK", MB_OK);

				{
					/*
					MessageBox(hWnd, "Not implemented yet", NULL, MB_OK);
					return 0;

					OPENFILENAME ofn;
					ZeroMemory(&ofn, sizeof(ofn));
					char retfname[MAX_PATH + 1] = {};
					ofn.lStructSize = sizeof(OPENFILENAME);
					ofn.hwndOwner = hWnd;
					ofn.lpstrFilter = "TRG file (*.trg)\0*.trg\0All files (*.*)\0*.*\0";
					ofn.lpstrFile = retfname;
					ofn.nMaxFile = MAX_PATH;
					ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST;
					ofn.lpstrDefExt = "trg";
					ofn.lpstrInitialDir = NULL;

					if(!GetOpenFileName(&ofn)) return 0;

					FILE* fp = fopen(retfname, "rb");
					if(!fp) {
						MessageBox(hWnd, "Cannot open selected file.", NULL, MB_OK);
						return 0;
					}

					int trgsize = ftell(fp) - 8;

					if(trgsize < 0 || trgsize % 2400 != 0) {
						MessageBox(hWnd, "Invalid TRG file.", NULL, MB_OK);
						fclose(fp);
						return 0;
					}

					fseek(fp, 8, SEEK_SET);

					BYTE* data = new BYTE[trgsize];
					fread(data, 1, trgsize, fp);
					fclose(fp);

					CChunkData trg;
					trg.ChunkData = data;
					trg.ChunkSize = trgsize;

					std::string buf = te->DecodeTriggers(&trg,1);
					te->SendSciMessage(SCI_ADDTEXT, buf.size(), (LPARAM)buf.data());
					return 0;
					*/
				}
				break;

			case IDM_FILE_COMPILE:
			case IDM_FILE_COMPILENONAG:
				if(te->EncodeTriggerCode(hWnd)) {
					// OK.
					HWND hStatusBar = GetDlgItem(hWnd, StatusBarID);
					SetWindowText(hStatusBar, "Trigger successfully updated");
					if(LOWORD(wParam) == IDM_FILE_COMPILE) MessageBox(hWnd, "Trigger successfully updated", "OK", MB_OK);
					te->SendSciMessage(SCI_SETSAVEPOINT, 0, 0);
					te->_textedited = false;
				}

				else {
					// Print error
					HWND hStatusBar = GetDlgItem(hWnd, StatusBarID);
					SetWindowText(hStatusBar, "Error on compiling");
					MessageBox(hWnd, te->_errlist.str().c_str(), NULL, MB_OK);
				}
				return 0;

			case IDM_VIEW_FOLDALL:
				te->SendSciMessage(SCI_FOLDALL, SC_FOLDACTION_CONTRACT, 0);
				te->SendSciMessage(SCI_SCROLLCARET, 0, 0);
				break;

			case IDM_VIEW_UNFOLDALL:
				te->SendSciMessage(SCI_FOLDALL, SC_FOLDACTION_EXPAND, 0);
				te->SendSciMessage(SCI_SCROLLCARET, 0, 0);
				break;

				// EDIT
			case IDM_EDIT_FIND:
			case IDM_EDIT_REPLACE:
			{
					if(te->hFindDlg)
					{
						DestroyWindow(te->hFindDlg);
						te->hFindDlg = NULL;
					}

					ZeroMemory(&fr, sizeof(fr));

					// Initialize FINDREPLACE
					fr.lStructSize = sizeof(fr);
					fr.hwndOwner = hWnd;
					//fr.hInstance = hInstance;
					fr.Flags = FR_DOWN;
					fr.lpstrFindWhat = szFindText;
					fr.lpstrReplaceWith = szReplaceText;
					ZeroMemory(szFindText, 4096);
					ZeroMemory(szReplaceText, 4096);

					// Get selected text and fill lpstrFindWhat with it.
					int selstart = te->SendSciMessage(SCI_GETSELECTIONSTART, 0, 0);
					int selend = te->SendSciMessage(SCI_GETSELECTIONEND, 0, 0);
					if(selend != selstart)
					{
						Sci_TextRange tr;
						tr.chrg.cpMin = selstart;
						tr.chrg.cpMax = selend;
						tr.lpstrText = new char[selend - selstart + 1];
						te->SendSciMessage(SCI_GETTEXTRANGE, 0, (LPARAM)&tr);
						strncpy(szFindText, tr.lpstrText, 4096);
						szFindText[4095] = '\0';
						delete[] tr.lpstrText;
					}

					fr.wFindWhatLen = 4096;
					fr.wReplaceWithLen = 4096;

					if(LOWORD(wParam) == IDM_EDIT_FIND) te->hFindDlg = FindText(&fr);
					else te->hFindDlg = ReplaceText(&fr);
				}
				return 0;

			case IDM_EDIT_AUTOCOMPLETE:
				ApplyAutocomplete(te);
				break;


			case IDM_EDIT_UNLOAD:
				/*
				fopen_s(&ftmp, TMPName.data(), "rb");
				if (ftmp == NULL)
					Cflag = 0;
				else
				{
					fseek(ftmp, 1, 0);
					fread(&Cflag, 1, 1, ftmp);
					fclose(ftmp);
				}
				if (Cflag != 2)
				{
					
				}
				else
					MessageBox(hWnd, "[VSCode Compile Mode] External .Lua files Unloaded.", "Info", MB_OK);
				*/
				Uprev = CheckMenuItem(hEdit, 5, MF_BYPOSITION);
				if (Uprev == MF_CHECKED)
				{
					Uprev = CheckMenuItem(hEdit, 5, MF_BYPOSITION | MF_UNCHECKED);
					MessageBox(hWnd, "External .Lua files Loaded.", "Info", MB_OK); // 

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					Uflag = 1;
					fwrite(&Uflag, 1, 1, ftmp);
					fclose(ftmp);
				}
				else
				{
					Uprev = CheckMenuItem(hEdit, 5, MF_BYPOSITION | MF_CHECKED);
					MessageBox(hWnd, "External .Lua files Unloaded.", "Info", MB_OK);

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					Uflag = 0;
					fwrite(&Uflag, 1, 1, ftmp);
					fclose(ftmp);
				}
				break;
			case IDM_CTRIG_UPDATE:
				ShellExecute(0, 0, "https://cafe.naver.com/marineraise/18754", 0, 0, SW_SHOW);
				return 0;
			case IDM_CTRIG_ABOUT:
				MessageBox(hWnd,
					"CtrigAsm v5.5 Made by Ninfia(tomijun@naver.com)\r\n"
					"STRCtrig(VSCode) Compile Mode for TrigEditPlus v" VERSION "\r\n",
					"Info", MB_OK);
				return 0;
			case IDM_CTRIG_INIT:
			{
				const char* newInittext =
					"SetForces({},{},{},{},{}) -- Force1~4, AllPlayers 입력\r\n"
					"SetFixedPlayer() -- 고정 플레이어 입력\r\n"
					"StartCtrig(1, nil, 0, 1, __CurrentPath) -- IncludeSTRx, IncludePlayer, NSQC, STRCTRIG, 현재경로\r\n" 
					"CJump(AllPlayers, 0)\r\n"
					"-- Include 또는 변수 선언 --\r\n"
					"Include_CtrigPlib(360, \"Switch 255\") -- 각도계, 랜덤스위치\r\n" 
					"\r\n"
					"CJumpEnd(AllPlayers, 0)\r\n"
					"-- 어셈블러 코드 입력 --\r\n"
					"\r\n"
					"EndCtrig()\r\n"
				;
				std::string out;
				utf16to8(ETptr, (char*)newInittext, out);
				te->SendSciMessage(SCI_REPLACESEL, 0, (LPARAM)(out.data()));
			}
				return 0;
			case IDM_CTRIG_LOADER:
			{
				const char* newLOADERtext =
					"__MapDirSetting() -- 맵파일 경로(\\를 \\\\로 바꿔야함)\r\n"
					"__SubDirSetting() -- Main.lua 폴더경로 (\\를 \\\\로 바꿔야함, 없으면 비우기)\r\n"
					/*
					"\r\n"
					"__StringArray = {} __UPUSCheckArray = {}\r\n"
					"__TRIGChkptr = io.open(__CurrentPath..\"/SCMD2TRIG.chk\", \"wb\")\r\n"
					"\r\n"
					"Dofile(__CurrentPath..\"/SCMD2Loader.lua\")\r\n"
					"Dofile(__Subdir..\"/Main.lua\")\r\n"
					"\r\n"
					"__PopStringArray()\r\n"
					"io.close(__TRIGchkptr)\r\n"
					*/
					;
				std::string out;
				utf16to8(ETptr, (char*)newLOADERtext, out);
				te->SendSciMessage(SCI_REPLACESEL, 0, (LPARAM)(out.data()));
			}
				return 0;
			case IDM_CTRIG_STRCTRIG:
			{
				DWORD Cprev = CheckMenuItem(hCtrig, 6, MF_BYPOSITION);
				if (Cprev == MF_CHECKED)
				{
					CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_UNCHECKED);
					CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_UNCHECKED);
					//EnableMenuItem(hEdit, 5, MF_BYPOSITION | MF_ENABLED);

					MessageBox(hWnd, "STRCtrig Compile Mode disabled.", "Info", MB_OK); 

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					fseek(ftmp, 1, 0);
					Cflag = 0;
					fwrite(&Cflag, 1, 1, ftmp);
					fclose(ftmp);
				}
				else
				{
					CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_CHECKED);
					CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_UNCHECKED);
					//EnableMenuItem(hEdit, 5, MF_BYPOSITION | MF_ENABLED);

					MessageBox(hWnd, "STRCtrig Compile Mode enabled.", "Info", MB_OK);

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					fseek(ftmp, 1, 0);
					Cflag = 1;
					fwrite(&Cflag, 1, 1, ftmp);
					fclose(ftmp);
				}
			}
				return 0;
			case IDM_CTRIG_VSCODE:
			{
				DWORD Cprev = CheckMenuItem(hCtrig, 7, MF_BYPOSITION);
				if (Cprev == MF_CHECKED)
				{
					CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_UNCHECKED);
					CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_UNCHECKED);
					//EnableMenuItem(hEdit, 5, MF_BYPOSITION | MF_ENABLED);

					MessageBox(hWnd, "VSCode Compile Mode disabled.", "Info", MB_OK);

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					fseek(ftmp, 1, 0);
					Cflag = 0;
					fwrite(&Cflag, 1, 1, ftmp);
					fclose(ftmp);
				}
				else
				{
					CheckMenuItem(hCtrig, 6, MF_BYPOSITION | MF_UNCHECKED);
					CheckMenuItem(hCtrig, 7, MF_BYPOSITION | MF_CHECKED);
					//EnableMenuItem(hEdit, 5, MF_BYPOSITION | MF_GRAYED);

					MessageBox(hWnd, "VSCode Compile Mode enabled.", "Info", MB_OK);

					fopen_s(&ftmp, TMPName.data(), "r+b");
					if (ftmp == NULL)
						fopen_s(&ftmp, TMPName.data(), "wb");
					fseek(ftmp, 1, 0);
					Cflag = 2;
					fwrite(&Cflag, 1, 1, ftmp);
					fclose(ftmp);

					/*
					FILE* flua;
					fopen_s(&flua, LoaderName.data(), "rb");
					if (flua == NULL)
					{
						fopen_s(&flua, LoaderName.data(), "wb");
						HRSRC ETResource = ::FindResource(hInstance, MAKEINTRESOURCE(IDR_LOADER), RT_RCDATA);
						HGLOBAL ETResourceData = ::LoadResource(hInstance, ETResource);
						void* ETptr = ::LockResource(ETResourceData);
						fwrite((char*)ETptr, 1, strlen((char*)ETptr), flua);
					}
					fclose(flua);
					*/
				}
			}
				return 0;
			case IDM_HELP_UPDATE:
				ShellExecute(0, 0, "https://cafe.naver.com/marineraise/20095", 0, 0, SW_SHOW);
				return 0;

			case IDM_HELP_NONAME:
				ShellExecute(0, 0, "http://ajwmain.iptime.org/", 0, 0, SW_SHOW);
				return 0;

			case IDM_HELP_EUDDB:
				ShellExecute(0, 0, "https://westreed.github.io/edac-eud-db/", 0, 0, SW_SHOW);
				return 0;

			case IDM_HELP_BLACKCAT:
				PicFunc();
				return 0;

			case IDM_HELP_ABOUTTRIGEDITPLUS:
				MessageBox(hWnd,
					"TrigEditPlus 0.07 Made by trgk(phu54321@naver.com)\r\n"
					"Simple & powerful trigger editor.\r\n"
					"This program uses Scintilla and Lua.\r\n"
					"TrigEditPlus v" VERSION " Updated by Ninfia (2024/03/18 00:00)\r\n",
					"Info", MB_OK);
				return 0;

			case IDM_HELP_LICENSES:
				MessageBox(hWnd,
					"TrigEditPlus is distributed in MIT License.\r\n"
					"Source code can be obtained at http://github.com/phu54321/TrigEditPlus/\r\n"
					"\r\n"
					"Copyright (c) 2014 trgk(phu54321@naver.com)\r\n"
					"\r\n"
					"Permission is hereby granted, free of charge, to any person obtaining a copy\r\n"
					"of this software and associated documentation files (the \"Software\"), to deal\r\n"
					"in the Software without restriction, including without limitation the rights\r\n"
					"to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\r\n"
					"copies of the Software, and to permit persons to whom the Software is\r\n"
					"furnished to do so, subject to the following conditions:\r\n"
					"\r\n"
					"The above copyright notice and this permission notice shall be included in\r\n"
					"all copies or substantial portions of the Software.\r\n"
					"\r\n"
					"THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r\n"
					"IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r\n"
					"FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r\n"
					"AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r\n"
					"LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r\n"
					"OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\r\n"
					"THE SOFTWARE.\r\n"
					, "TrigEditPlus License", MB_OK);

				MessageBox(hWnd,
					"Copyright 1994-2014 Lua.org, PUC-Rio.\r\n"
					"Permission is hereby granted, free of charge, to any person obtaining a copy of\r\n"
					"this software and associated documentation files (the \"Software\"), to deal in\r\n"
					"the Software without restriction, including without limitation the rights to\r\n"
					"use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies\r\n"
					"of the Software, and to permit persons to whom the Software is furnished to do\r\n"
					"so, subject to the following conditions:\r\n"
					"\r\n"
					"The above copyright notice and this permission notice shall be included in all\r\n"
					"copies or substantial portions of the Software.\r\n"
					"\r\n"
					"THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\r\n"
					"IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\r\n"
					"FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\r\n"
					"AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\r\n"
					"LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\r\n"
					"OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\r\n"
					"SOFTWARE.\r\n",
					"Lua License",
					MB_OK);

				MessageBox(hWnd,
					"License for Scintilla and SciTE\r\n"
					"\r\n"
					"Copyright 1998-2002 by Neil Hodgson <neilh@scintilla.org>\r\n"
					"\r\n"
					"All Rights Reserved \r\n"
					"\r\n"
					"Permission to use, copy, modify, and distribute this software and its \r\n"
					"documentation for any purpose and without fee is hereby granted, \r\n"
					"provided that the above copyright notice appear in all copies and that \r\n"
					"both that copyright notice and this permission notice appear in \r\n"
					"supporting documentation. \r\n"
					"\r\n"
					"NEIL HODGSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS \r\n"
					"SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY \r\n"
					"AND FITNESS, IN NO EVENT SHALL NEIL HODGSON BE LIABLE FOR ANY \r\n"
					"SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES \r\n"
					"WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, \r\n"
					"WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER \r\n"
					"TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE \r\n"
					"OR PERFORMANCE OF THIS SOFTWARE. \r\n",
					"Scintilla License",
					MB_OK);

				return 0;

			case IDM_EDIT_NEWDOACTS:
			{
				const char* newtriggertext =
					"DoActions (\r\n"
					"	{},\r\n"
					"	{\r\n"
					"		\r\n"
					"	}\r\n"
					")\r\n"
					;
				te->SendSciMessage(SCI_REPLACESEL, 0, (LPARAM)newtriggertext);
			}
			return 0;


			case IDM_EDIT_NEWTRIGGER:
				{
					const char* newtriggertext = 
						"Trigger {\r\n"
						"	players = {},\r\n"
						"	conditions = {\r\n"
						"		\r\n"
						"	},\r\n"
						"	actions = {\r\n"
						"		\r\n"
						"	},\r\n"
						"	flag = {}\r\n"
						"}\r\n"
						;
					te->SendSciMessage(SCI_REPLACESEL, 0, (LPARAM)newtriggertext);
				}
				return 0;

			case IDA_LISTUP:
			{
				HWND hElmnTable = te->hElmnTable;
				int total = ListBox_GetCount(hElmnTable);
				int current_item = ListBox_GetCurSel(hElmnTable);
				if (total > 0)
				{
					if (current_item == LB_ERR)
						ListBox_SetCurSel(hElmnTable, 0);
					else if (current_item > 0)
						ListBox_SetCurSel(hElmnTable, current_item - 1);
					else
						ListBox_SetCurSel(hElmnTable, 0);
				}
				return 0;
			}

			case IDA_LISTDOWN:
			{
				HWND hElmnTable = te->hElmnTable;
				int total = ListBox_GetCount(hElmnTable);
				int current_item = ListBox_GetCurSel(hElmnTable);
				if (total > 0)
				{
					if (current_item == LB_ERR)
						ListBox_SetCurSel(hElmnTable, 0);
					else if (current_item < total - 1)
						ListBox_SetCurSel(hElmnTable, current_item + 1);
					else
						ListBox_SetCurSel(hElmnTable, total - 1);
				}
				return 0;
			}

			case IDA_LISTUPX:
			{
				HWND hElmnTable = te->hElmnTable;
				int total = ListBox_GetCount(hElmnTable);
				int current_item = ListBox_GetCurSel(hElmnTable);
				if (total > 0)
				{
					int Page = total / 10;
					if (Page == 0) Page = 1;
					if (current_item == LB_ERR)
						ListBox_SetCurSel(hElmnTable, 0);
					else if (current_item - Page >= 0)
						ListBox_SetCurSel(hElmnTable, current_item - Page);
					else
						ListBox_SetCurSel(hElmnTable, 0);
				}
				return 0;
			}

			case IDA_LISTDOWNX:
			{
				HWND hElmnTable = te->hElmnTable;
				int total = ListBox_GetCount(hElmnTable);
				int current_item = ListBox_GetCurSel(hElmnTable);
				if (total > 0)
				{
					int Page = total / 10;
					if (Page == 0) Page = 1;
					if (current_item == LB_ERR)
						ListBox_SetCurSel(hElmnTable, 0);
					else if (current_item + Page <= total - 1)
						ListBox_SetCurSel(hElmnTable, current_item + Page);
					else
						ListBox_SetCurSel(hElmnTable, total - 1);
				}
				return 0;
			}

			case ElmnTableID:
				if(HIWORD(wParam) == LBN_DBLCLK) {
					ApplyAutocomplete(te);
					SetFocus(te->hScintilla);
				}
				return 0;
			}
		
		}
		break;

	case WM_NOTIFY:
		if(wParam == ScintillaID) {
			SCNotification *ne = reinterpret_cast<SCNotification*>(lParam);
			switch(ne->nmhdr.code) {
			case SCN_SAVEPOINTREACHED:
				SetWindowText(hWnd, "TrigEditPlus " VERSION);
				te->_textedited = false;
				return 0;

			case SCN_SAVEPOINTLEFT:
				SetWindowText(hWnd, "TrigEditPlus " VERSION " (Modified)");
				te->_textedited = true;
				return 0;

			case SCN_MARGINCLICK:
				{
					const int modifiers = ne->modifiers;
					const int position = ne->position;
					const int margin = ne->margin;
					const int line_number = te->SendSciMessage(SCI_LINEFROMPOSITION, position, 0);

					switch (margin) {
					case 2:
						{
							te->SendSciMessage(SCI_TOGGLEFOLD, line_number, 0);
						}
						break;
					}
				}
				return 0;

			case SCN_CHARADDED:
				Editor_CharAdded(ne, te);
				return 0;
			}
		}
		break;

	case WM_CLOSE:
		{
			if(te->_textedited) {
				int select = MessageBox(hWnd, "There are unsaved change in trigger text. Compile?", "Save warning", MB_YESNOCANCEL);
				/**/ if(select == IDCANCEL) return 0;
				else if(select == IDNO);
				else {
					if(te->EncodeTriggerCode(hWnd));
					else {
						MessageBox(hWnd, te->_errlist.str().c_str(), NULL, MB_OK);
						return 0;
					}
				}
			}
		}
		break;

	case WM_DESTROY:
		{
			if(te->hFindDlg) DestroyWindow(te->hFindDlg);
			EnableWindow(hSCMD2MainWindow, TRUE);
			te->hTrigDlg = NULL;
			te->hScintilla = NULL;
			te->hFindDlg = NULL;
			te->_pSciMsg = NULL;
			te->_pSciWndData = NULL;
			SetFocus(hSCMD2MainWindow);
		}
		return 0;

	}


	if(msg == FindReplaceMsg) {
		ProcessSearchMessage(hWnd, te, (SearchQuery*)lParam, te->GetEditorText().size());
		return 0;
	}

	return DefWindowProc(hWnd, msg, wParam, lParam);
}




void ProcessSearchMessage(HWND hTrigDlg, TriggerEditor* te, SearchQuery* q, int editlen) {
	LPFINDREPLACE lpfr = &fr;
	HWND hStatusBar = GetDlgItem(hTrigDlg, StatusBarID);

	if(lpfr->Flags & FR_DIALOGTERM)
	{
		te->hFindDlg = NULL;
	}

	else if(lpfr->Flags & FR_FINDNEXT || lpfr->Flags & FR_REPLACE)
	{	
		ConvertText();
		// Find/replace
		int searchflag =
			((lpfr->Flags & FR_MATCHCASE) ? SCFIND_MATCHCASE : 0) |
			((lpfr->Flags & FR_WHOLEWORD) ? SCFIND_WHOLEWORD : 0);

		int retv;

		// Init ttf
		Sci_TextToFind ttf;
		ttf.lpstrText = lpfr->lpstrFindWhat;

		if(lpfr->Flags & FR_DOWN)
		{
			ttf.chrg.cpMin = max(
				te->SendSciMessage(SCI_GETCURRENTPOS, 0, 0),
				te->SendSciMessage(SCI_GETANCHOR, 0, 0)
				);
			ttf.chrg.cpMax = te->SendSciMessage(SCI_GETLENGTH, 0, 0);
		}

		else
		{
			ttf.chrg.cpMin = min(
				te->SendSciMessage(SCI_GETCURRENTPOS, 0, 0),
				te->SendSciMessage(SCI_GETANCHOR, 0, 0)
				);
			ttf.chrg.cpMax = 0;
		}

		retv = te->SendSciMessage(SCI_FINDTEXT, searchflag, (LPARAM)&ttf);
		if(retv == -1)  // Not found yet
		{
			// Search in global context
			if(lpfr->Flags & FR_DOWN)
			{
				ttf.chrg.cpMin = 0;
				ttf.chrg.cpMax = te->SendSciMessage(SCI_GETLENGTH, 0, 0);
			}

			else
			{
				ttf.chrg.cpMin = te->SendSciMessage(SCI_GETLENGTH, 0, 0);
				ttf.chrg.cpMax = 0;
			}

			retv = te->SendSciMessage(SCI_FINDTEXT, searchflag, (LPARAM)&ttf);

			if(retv != -1)
			{
				SetWindowText(hStatusBar, "Passed the end of the document");
			}
		}

		if(retv == -1) // No such text in global context
		{
			const char* outstr = "Cannot find specified string.";
			MessageBox(hTrigDlg, outstr, "Result", MB_OK);
			SetWindowText(hStatusBar, outstr);
			MessageBeep(MB_OK);
			return;
		}

		// Select the text
		te->SendSciMessage(SCI_SETSEL, ttf.chrgText.cpMin, ttf.chrgText.cpMax);

		// Replace if needed.
		if(lpfr->Flags & FR_REPLACE)
		{
			te->SendSciMessage(SCI_REPLACESEL, 0, (LPARAM)lpfr->lpstrReplaceWith);
		}
	}

	else if(lpfr->Flags & FR_REPLACEALL)
	{
		ConvertText();
		//const int docLen = te->SendSciMessage(SCI_GETLENGTH, 0, 0);
		const int docLen = editlen;
		int replacedn = 0;

		const int searchflag =
			((lpfr->Flags & FR_MATCHCASE) ? SCFIND_MATCHCASE : 0) |
			((lpfr->Flags & FR_WHOLEWORD) ? SCFIND_WHOLEWORD : 0);

		const int searchlen = strlen(lpfr->lpstrFindWhat);
		const int replen = strlen(lpfr->lpstrReplaceWith);

		te->SendSciMessage(SCI_SETTARGETSTART, 0, 0);
		te->SendSciMessage(SCI_SETSEARCHFLAGS, searchflag, 0);

		te->SendSciMessage(SCI_BEGINUNDOACTION, 0, 0);

		while(1)
		{
			// find next text
			te->SendSciMessage(SCI_SETTARGETEND, docLen, 0);
			if(te->SendSciMessage(SCI_SEARCHINTARGET, searchlen, (LPARAM)lpfr->lpstrFindWhat) == -1) break;
			te->SendSciMessage(SCI_REPLACETARGET, replen, (LPARAM)lpfr->lpstrReplaceWith);

			// move target after the replaced text
			int newtargetend = te->SendSciMessage(SCI_GETTARGETEND, 0, 0);
			te->SendSciMessage(SCI_SETTARGETSTART, newtargetend, 0);
			replacedn++;
		}

		te->SendSciMessage(SCI_ENDUNDOACTION, 0, 0);

		if(replacedn == 0)
		{
			const char* outstr = "Cannot find specified string.";
			MessageBox(hTrigDlg, outstr, "Result", MB_OK);
			SetWindowText(hStatusBar, outstr);
			MessageBeep(MB_OK);
		}

		else
		{
			char outstr[512];
			sprintf(outstr, "Replaced %d strings.", replacedn);
			SetWindowText(hStatusBar, outstr);
			MessageBeep(MB_OK);
		}

		return;
	}
}