#pragma once
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include "resource.h"
using namespace std;
typedef unsigned long long QWORD;
/*
DWORD EPD(DWORD PTR)
{
    return (PTR >> 2) - 1452249;
}
*/
#define EPD(X) (((X)>>2)-1452249)

int PatchTRIG(vector<Trig>& fin, string mapdir, int PlayerSet[], int TRIGcount)
{
    int Size = fin.size() - (TRIGcount + 3);

    /*
        �� == 1 üũ
        + 0x944 : P1
        + 0x945 : P2
        + 0x946 : P3
        + 0x947 : P4
        + 0x948 : P5
        + 0x949 : P6
        + 0x94A : P7
        + 0x94B : P8

        + 0x94C : P9
        + 0x94D : P10
        + 0x94E : P11
        + 0x94F : P12

        + 0x955 : AllPlayers
        + 0x956 : Force1
        + 0x957 : Force2
        + 0x958 : Force3
        + 0x959 : Force4
        Real TRIG SIZE : 0x970
    */

    int Force[4][8] = { { 0 }, { 0 }, { 0 }, { 0 } };
    int AllPlayers[8] = { 0 };
    for (int i = 0; i < 8; i++)
    {
        if ((PlayerSet[i] & 1) == 1)
            Force[0][i] = 1;
        if ((PlayerSet[i] & 2) == 2)
            Force[1][i] = 1;
        if ((PlayerSet[i] & 4) == 4)
            Force[2][i] = 1;
        if ((PlayerSet[i] & 8) == 8)
            Force[3][i] = 1;
        if ((PlayerSet[i] & 16) == 16)
            AllPlayers[i] = 1;
    }

    FILE* fout;
    fopen_s(&fout, "SCMD2Result.txt", "w");
    if (fout == NULL)
        return 1;
   
    fprintf(fout,"--------------------------------------\n  ��`+��STRCtrigAssembler v1.4 for Tep v3.0 ��+.��\n--------------------------------------\n\t\t\tMade By Ninfia\n\n");
    fprintf(fout,"- PatchTRIG for STRCtrigAssembler v1.4 -\n\n");

    HRSRC chkResource = ::FindResource(hInstance, MAKEINTRESOURCE(IDR_STRCTRIG), RT_RCDATA);
    HGLOBAL chkResourceData = ::LoadResource(hInstance, chkResource);
    void* chkptr = ::LockResource(chkResourceData);

    int Loc0 = 0;
    int Loc[8] = { 0,0,0,0,0,0,0,0 };
    int Check[8] = { 0 };
    DWORD Pbuffer[7] = { 0 };
    QWORD* Ptmp = (QWORD*)Pbuffer;
    DWORD buffer[600] = { 0 };
    DWORD VoidAct[512] = { 0 };
    DWORD Void[604] = { 0 };
    DWORD VoidX[604] = { 0 };
    DWORD File[604] = { 0 };
    DWORD TRIG[600] = { 0 };
    QWORD Blank = 0;
    DWORD Dummy;
    BYTE Voidflag, Fileflag, VArrflag, TRIGflag, STRxflag;
    
    // make TRIG.chk dir
    std::string NewPath = mapdir + "\\Ctemp";
    _mkdir(NewPath.data());

    FILE* OTRIG;
    string ostr = mapdir + "\\Ctemp\\TRIGP0.chk";
    fopen_s(&OTRIG, ostr.data(), "w+b");
    if (OTRIG == NULL)
    {
        fclose(fout);
        fclose(OTRIG);
        return 1;
    }
    char PName[] = "\\Ctemp\\TRIGP1.chk";
    FILE* PTRIG[8];
    for (int i = 0; i < 8; i++)
    {
        PName[12] = i + '1';
        string nstr = mapdir + PName;
        fopen_s(&PTRIG[i], nstr.data(), "w+b");
        if (PTRIG[i] == NULL)
        {
            fclose(OTRIG);
            fclose(fout);
            for (int j = 0; j < i; j++)
                fclose(PTRIG[j]);
            return 1;
        }
    }
    
    for (int i = 1; i <= Size; i++)
    {
        for (int k = 0; k < 8; k++) // Clear Check
            Check[k] = 0;
        Fileflag = 0;
        Voidflag = 0;
        VArrflag = 0;
        TRIGflag = 0;
        STRxflag = 0;
        
        if (fin[i].flag >= 0x80) // STRxflag
        {
            STRxflag = 1;
            fin[i].flag -= 0x80;
        }
        for (int k = 0; k < 8; k++) // P1 ~ P8 Check
        {
            if (fin[i].effplayer[k] == 1)
                Check[k] = 1;   
        }

        if (fin[i].effplayer[17] == 1) // AllPlayers Check
        {
            for (int k = 0; k < 8; k++)
                if (AllPlayers[k] == 1)
                    Check[k] = 1;
        }

        for (int l = 0; l < 4; l++)
        {
            if (fin[i].effplayer[18+l] == 1) // Force 1~4 Check
                for (int k = 0; k < 8; k++)
                    if (Force[l][k] == 1)
                        Check[k] = 1;
        }

        if (fin[i].effplayer[8] == 1) // P9 = f_GetFileptr
            Fileflag = 1;

        if (fin[i].effplayer[9] == 1) // P10 = f_GetVoidptr
            Voidflag = 1;

        if (fin[i].effplayer[10] == 1) // P11 = f_GetVArrptr
            VArrflag = 1;

        if (fin[i].effplayer[11] == 1) // P12 = f_GetTRIGptr
            TRIGflag = 1;

        if (Fileflag + Voidflag + VArrflag + TRIGflag > 1) // Remove Error
            continue;

        FILE* fadd;
        char fName[512] = { 0 };
        DWORD* fptr;
        DWORD fNum, fsize;
        for (int k = 0; k < 8; k++) // Write TRIG
        {
            if (Check[k] == 1)
            {
                if (Fileflag == 1)
                {
                    fptr = (DWORD*)fName;
                    DWORD Repeat = fin[i].act[0].player;
                    for (int l = 0; l < 64; l++)
                    {
                        fptr[2 * l] = fin[i].act[l].locid;

                        Dummy = fptr[2 * l + 1] = fin[i].act[l].target;
                        
                        if (Dummy == 0)
                            break;
                    }
                    fopen_s(&fadd, fName, "rb");
                    fseek(fadd, 0, 2);
                    fsize = ftell(fadd);
                    fseek(fadd, 0, 0);
                    fNum = ceil((double)(fsize) / (double)0x970);
                    int FNum = ceil((fsize * Repeat) / (double)0x970);
                    Loc[k] += 0x970;
                    Blank = Loc[k];
                    Blank <<= 32;
                    Blank += FNum;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8

                    memcpy(buffer, &(fin[i]), 2400);
                    fwrite(buffer, 4, 80, PTRIG[k]); // 0x8 ~ 0x148
                    fwrite(VoidAct, 4, 512, PTRIG[k]); // 0x148 ~ 0x948
                    fwrite(buffer+592, 4, 8, PTRIG[k]); // 0x948 ~ 0x968

                    Blank = 0;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970

                    int Count = 0;
                    int psize = fsize;
                    for (DWORD l = 0; l < Repeat; l++)
                    {
                        fsize = psize;
                        fseek(fadd, 0, 0);
                        for (DWORD j = 0; j < fNum; j++)
                        {
                            Count++;
                            DWORD transbyte = min(fsize, 0x970);
                            fread(File, transbyte, 1, fadd);
                            fwrite(File, transbyte, 1, PTRIG[k]); // 0x0 ~ 0x970 Void
                            fsize -= 0x970;
                            if (Count > 0x100000)
                                goto OUT2;
                        }
                    }
                OUT2:
                    int sbyte = 0x970 * FNum - psize * Repeat;
                    if (sbyte > 0)
                        fwrite(Void, sbyte, 1, PTRIG[k]);
                    else if (sbyte < 0)
                        fprintf(fout,"f_GetFileptr : ������ �߻��߽��ϴ�.\n");
                    Loc[k] += 0x970 * FNum;
                    fclose(fadd);
                    fprintf(fout,"%s �ε� �Ϸ�\nf_GetFileptr : P%d �� TRIG�� %dbytes ����� (x%d)\n", fName, k + 1, FNum * 0x970, Repeat);
                }
                else if (Voidflag == 1)
                {
                    DWORD Fill;
                    Loc[k] += 0x970;
                    Blank = Loc[k];
                    Blank <<= 32;

                    Fill = fin[i].act[0].locid;
                    if (Fill)
                        for (DWORD j = 0; j < 604; j++)
                            VoidX[j] = Fill;

                    Dummy = fin[i].act[0].target;
                    Blank += Dummy;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8

                    memcpy(buffer, &(fin[i]), 2400);
                    fwrite(buffer, 4, 80, PTRIG[k]); // 0x8 ~ 0x148
                    fwrite(VoidAct, 4, 512, PTRIG[k]); // 0x148 ~ 0x948
                    fwrite(buffer + 592, 4, 8, PTRIG[k]); // 0x948 ~ 0x968

                    Blank = 0;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970

                    int Count = 0;
                    for (DWORD j = 0; j < Dummy; j++)
                    {
                        Count++;
                        Loc[k] += 0x970;
                        if (!Fill)
                            fwrite(Void, 4, 604, PTRIG[k]); // 0x0 ~ 0x970 Void
                        else
                            fwrite(VoidX, 4, 604, PTRIG[k]); // 0x0 ~ 0x970 Void
                        if (Count > 0x100000)
                            break;
                    }

                    fprintf(fout,"f_GetVoidptr : P%d �� TRIG�� %dbytes �Ҵ��\n", k + 1, Count * 0x970);
                }
                else if (VArrflag == 1)
                {
                    Loc[k] += 0x970;
                    Blank = Loc[k];
                    Blank <<= 32;
                    Dummy = fin[i].act[0].target;
                    Blank += Dummy;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8

                    memcpy(buffer, &(fin[i]), 2400);
                    fwrite(buffer, 4, 80, PTRIG[k]); // 0x8 ~ 0x148
                    fwrite(VoidAct, 4, 512, PTRIG[k]); // 0x148 ~ 0x948
                    fwrite(buffer + 592, 4, 8, PTRIG[k]); // 0x948 ~ 0x968

                    Blank = 0;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970

                    int findex = fin[i].act[0].locid;
                    memcpy(buffer, ((BYTE*)chkptr) + (findex - 1) * 0x960 + 0x12C8, 0x960);

                    int Count = 0;
                    Blank = 0;
                    char PCheck = 1;
                    for (DWORD j = 0; j < Dummy; j++)
                    {
                        Count++;
                        Loc[k] += 0x970;
                        fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8
                        fwrite(buffer, 4, 600, PTRIG[k]); // 0x8 ~ 0x968
                        fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970
                        int tmp = ftell(PTRIG[k]);

                        fseek(PTRIG[k], -44 + k, 1);
                        fwrite(&PCheck, 1, 1, PTRIG[k]);
                        fseek(PTRIG[k], tmp, 0);
                        if (Count > 0x100000)
                            break;
                    }
                    if (findex == 1)
                        fprintf(fout,"f_GetVArrptr : P%d �� TRIG�� VA[%d] (%dbytes) ������\n", k + 1, Count, Count * 0x970);
                    else if (findex == 2)
                        fprintf(fout,"f_GetWArrptr : P%d �� TRIG�� WA[%d] (%dbytes) ������\n", k + 1, Count, Count * 0x970);
                    else
                        fprintf(fout,"f_GetSVArrptr : P%d �� TRIG�� SVA%d[%d] (%dbytes) ������\n", k + 1, findex - 2, Count, Count * 0x970);
                }
                else if (TRIGflag == 1)
                {
                    fptr = (DWORD*)fName;
                    DWORD Repeat = fin[i].act[0].player;
                    for (int l = 0; l < 64; l++)
                    {
                        fptr[2 * l] = fin[i].act[l].locid;

                        Dummy = fptr[2 * l + 1] = fin[i].act[l].target;

                        if (Dummy == 0)
                            break;
                    }
                    fopen_s(&fadd, fName, "rb");
                    fseek(fadd, 0, 2);
                    fsize = ftell(fadd);
                    fseek(fadd, 0, 0);
                    fNum = ceil((double)(fsize) / (double)0x970);
                    int FNum = ceil((fsize * Repeat) / (double)0x970);
                    Loc[k] += 0x970;
                    Blank = Loc[k];
                    Blank <<= 32;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8

                    memcpy(buffer, &(fin[i]), 2400);
                    fwrite(buffer, 4, 80, PTRIG[k]); // 0x8 ~ 0x148
                    fwrite(VoidAct, 4, 512, PTRIG[k]); // 0x148 ~ 0x948
                    fwrite(buffer + 592, 4, 8, PTRIG[k]); // 0x948 ~ 0x968

                    Blank = 0;
                    fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970

                    int Count = 0;
                    int psize = fsize;
                    for (DWORD l = 0; l < Repeat; l++)
                    {
                        fsize = psize;
                        fseek(fadd, 0, 0);
                        for (DWORD j = 0; j < fNum; j++)
                        {
                            Count++;
                            DWORD transbyte = min(fsize, 0x970);
                            fread(File, transbyte, 1, fadd);
                            Loc[k] += 0x970;
                            File[1] = Loc[k];
                            fwrite(File, transbyte, 1, PTRIG[k]); // 0x0 ~ 0x970 Void
                            fsize -= 0x970;
                            if (Count > 0x100000)
                                goto OUT2X;
                        }
                    }
                OUT2X:

                    int sbyte = 0x970 * FNum - psize * Repeat;
                    if (sbyte > 0)
                        fwrite(Void, sbyte, 1, PTRIG[k]);
                    else if (sbyte < 0)
                        fprintf(fout,"f_GetTRIGptr : ������ �߻��߽��ϴ�.\n");
                    fclose(fadd);
                    fprintf(fout,"%s �ε� �Ϸ�\nf_GetTRIGptr : P%d �� TRIG�� CTRIG x%d (%dbytes) ����� (x%d)\n", fName, k + 1, FNum, FNum * 0x970, Repeat);
                }
                else
                {
                    if (STRxflag == 1)
                    {
                        Loc[k] += 0x970;
                        Blank = Loc[k];
                        Blank <<= 32;
                        fwrite(&Blank, 8, 1, PTRIG[k]); // 0x0 ~ 0x8

                        memcpy(buffer, &(fin[i]), 2400);
                        fwrite(buffer, 4, 600, PTRIG[k]); // 0x8 ~ 0x968

                        Blank = 0;
                        fwrite(&Blank, 8, 1, PTRIG[k]); // 0x968 ~ 0x970
                    }
                    else
                    {
                        Loc0 += 0x960;
                        memcpy(buffer, &(fin[i]), 2400);
                        *Ptmp = (unsigned long long)1 << (k << 3);
                        fwrite(buffer, 4, 593, OTRIG); // 0 ~ 0x944 
                        fwrite(Pbuffer, 4, 7, OTRIG); // 0x944 ~ 0x960
                    }
                }
            }
        }
    }

    int PSize0;
    PSize0 = ftell(OTRIG);
    int PSize[8];
    for (int k = 0; k < 8; k++)
        PSize[k] = ftell(PTRIG[k]);

    fprintf(fout,"\nTRIG Section : All %d Triggers / 0x%X bytes\n", Size, Size * 0x970);
    fprintf(fout, "TRIGP0.chk : %d Triggers / 0x%X bytes\n", Loc0 / 0x960, PSize0);
    for (int k = 0; k < 8; k++)
        fprintf(fout,"TRIGP%d.chk : %d Triggers / 0x%X bytes\n", k + 1, Loc[k] / 0x970, PSize[k]);
    fprintf(fout,"\n");
   
    // OnInitCtrig
    DWORD Prohibited_Label = 0xFFE0;
    DWORD* Table[8];
    BYTE* STable[8];
    for (int k = 0; k < 8; k++)
    {
        Table[k] = new DWORD[0x20000];
        STable[k] = new BYTE[0x20000];
        std::fill(Table[k], Table[k] + 0x20000, 0);
        std::fill(STable[k], STable[k] + 0x20000, 0);
    }
    DWORD Tableptr = 0;
    DWORD STRIG[604] = { 0 };
    DWORD tmp4;
    BYTE tmp1, * ptmp1, PID, tmp8[8];
    DWORD Tsize;
    DWORD CurSize[8] = { 0 };
    // 1st Loop : Check Label
    fseek(OTRIG, 0, 2);
    Tsize = ftell(OTRIG);
    for (DWORD i = 0; i < Tsize; i += 0x960)
    {
        fseek(OTRIG, 0x944 + i, 0);
        fread(&tmp8, 1, 8, OTRIG);
        if (tmp8[0] == 1) PID = 0;
        else if (tmp8[1] == 1) PID = 1;
        else if (tmp8[2] == 1) PID = 2;
        else if (tmp8[3] == 1) PID = 3;
        else if (tmp8[4] == 1) PID = 4;
        else if (tmp8[5] == 1) PID = 5;
        else if (tmp8[6] == 1) PID = 6;
        else if (tmp8[7] == 1) PID = 7;

        fseek(OTRIG, 0xF + i, 0);
        fread(&tmp1, 1, 1, OTRIG);
        if (tmp1 == 0xFE) // Label Check
        {
            fseek(OTRIG, 0x8 + i, 0);
            fread(&tmp4, 4, 1, OTRIG); // Index = tmp4
            Table[PID][tmp4] = CurSize[PID]; // Next = Table + 0x970
            //STable[PID][tmp4] = 0; // default
        }          
        CurSize[PID] += 0x970;

        if (tmp1 == 0xFB) // Prev StartCtrig (TRIG Base -0x970)
            CurSize[PID] = 0;
    }

    for (int k = 0; k < 8; k++) // 1st Loop : Check Label
    {
        fseek(PTRIG[k], 0, 2);
        Tsize = ftell(PTRIG[k]);
        for (DWORD i = 0; i < Tsize; i += 0x970)
        {
            fseek(PTRIG[k], 0x17 + i, 0);
            fread(&tmp1, 1, 1, PTRIG[k]);
            if (tmp1 == 0xFE) // Label Check
            {
                fseek(PTRIG[k], 0x10 + i, 0);
                fread(&tmp4, 4, 1, PTRIG[k]); // Index = tmp4
                Table[k][tmp4] = i; // Next = Table + 0x970
                STable[k][tmp4] = 1;
            }
            fseek(PTRIG[k], i, 0);
            fread(&tmp4, 4, 1, PTRIG[k]);
            if (tmp4 > 0)
                i += tmp4 * 0x970;
        }
    }

    for (int k = 0; k < 8; k++)
        CurSize[k] = 0;

    // 2nd Loop : Patch Ctrig
    fseek(OTRIG, 0, 2);
    Tsize = ftell(OTRIG);
    BYTE OWNR;
    for (DWORD i = 0; i < Tsize; i += 0x960)
    {
        fseek(OTRIG, i, 0);
        fread(TRIG, 4, 600, OTRIG);
        ptmp1 = (BYTE*)TRIG;

        if (ptmp1[0x944] == 1) OWNR = 0;
        else if (ptmp1[0x945] == 1) OWNR = 1;
        else if (ptmp1[0x946] == 1) OWNR = 2;
        else if (ptmp1[0x947] == 1) OWNR = 3;
        else if (ptmp1[0x948] == 1) OWNR = 4;
        else if (ptmp1[0x949] == 1) OWNR = 5;
        else if (ptmp1[0x94A] == 1) OWNR = 6;
        else if (ptmp1[0x94B] == 1) OWNR = 7;

        if (ptmp1[0xF] == 0xFE) // Label Check
        {
            //DWORD Label = TRIG[4];

            for (int j = 8; j <= 78; j += 5) // Condition Patch
            {
                int j4 = j << 2;
                DWORD CondID = (TRIG[j] & 0xFF000000) >> 24;
                if (CondID == 0)
                    break;
                else if (CondID == 0xFF) // Ctrig Condition
                {
                    DWORD index = 0;
                    DWORD player = OWNR;
                    DWORD Pflag = 0;

                    if ((TRIG[j + 1] & 0x40) == 0x40) // Cflag
                    {
                        index = Prohibited_Label;
                        Table[OWNR][index] = CurSize[OWNR];
                    }
                    else
                    {
                        index = TRIG[j] & 0xFFFF;
                        if ((TRIG[j + 1] & 0x80) == 0x80) // Xflag
                            index += 0x10000;
                    }

                    Pflag = TRIG[j + 1] & 0xF;
                    if (Pflag > 0)
                        player = Pflag - 1;

                    if ((TRIG[j + 1] & 0x10) == 0x10) // Nflag
                        TRIG[j - 2] = EPD(Table[player][index] + 0x970) + TRIG[j - 2];
                    else
                        TRIG[j - 2] = EPD(Table[player][index]) + TRIG[j - 2];

                    if (STable[player][index] == 1) // STRx Flag
                        TRIG[j] |= 0x800000;

                    ptmp1[j4 + 4] = 0; // Clear Cond
                    ptmp1[j4 + 3] = 0xF0 + player + 1;
                    ptmp1[j4 + 0] = 0;
                    ptmp1[j4 + 1] = 0;
                }
                else
                    continue;
            }

            for (int j = 86; j <= 590; j += 8) // Action Patch
            {
                int j4 = j << 2;
                DWORD ActID = (TRIG[j] & 0xFF0000) >> 16;
                if (ActID == 0)
                    break;
                else if (ActID == 0x5) // Ctrig Action
                {
                    DWORD index1 = 0, index2 = 0;
                    DWORD player1 = OWNR, player2 = OWNR;
                    DWORD Pflag1 = 0, Pflag2 = 0;

                    if ((TRIG[j - 4] & 0x20) == 0x20) // Cflag1
                    {
                        index1 = Prohibited_Label;
                        Table[OWNR][index1] = CurSize[OWNR];
                    }
                    else
                    {
                        index1 = TRIG[j - 5] & 0xFFFF;
                        if ((TRIG[j - 4] & 0x40) == 0x40) // Xflag1
                            index1 += 0x10000;
                    }

                    if ((TRIG[j - 3] & 0x80) == 0x80) // Cflag2
                    {
                        index2 = Prohibited_Label;
                        Table[OWNR][index2] = CurSize[OWNR];
                    }
                    else
                    {
                        index2 = TRIG[j] & 0xFFFF;
                        if ((TRIG[j - 4] & 0x80) == 0x80) // Xflag2
                            index2 += 0x10000;
                    }

                    if (index1 >= 1) // EPD
                    {
                        Pflag1 = TRIG[j - 4] & 0xF; // Pflag1
                        if (Pflag1 > 0)
                            player1 = Pflag1 - 1;

                        if ((TRIG[j - 4] & 0x10) == 0x10) // Nflag1
                            TRIG[j - 2] = EPD(Table[player1][index1] + 0x970) + TRIG[j - 2];
                        else
                            TRIG[j - 2] = EPD(Table[player1][index1]) + TRIG[j - 2];

                        if (STable[player1][index1] == 1) // STRx Flag1
                            TRIG[j] |= 0x80000000;
                    }
                    int Eflag;
                    if (index2 >= 1)
                    {
                        Pflag2 = TRIG[j - 3] & 0xF; // Pflag2
                        if (Pflag2 > 0)
                            player2 = Pflag2 - 1;

                        if ((TRIG[j - 3] & 0x10) == 0x10) // Nflag2
                            if ((TRIG[j - 3] & 0x20) == 0x20) // Eflag2
                            {
                                TRIG[j - 1] = EPD(Table[player2][index2] + 0x970) + TRIG[j - 1];
                                Eflag = 1;
                            }
                            else
                            {
                                TRIG[j - 1] = Table[player2][index2] + 0x970 + TRIG[j - 1];
                                Eflag = 0;
                            }
                        else
                            if ((TRIG[j - 3] & 0x20) == 0x20) // Eflag2
                            {
                                TRIG[j - 1] = EPD(Table[player2][index2]) + TRIG[j - 1];
                                Eflag = 1;
                            }
                            else
                            {
                                TRIG[j - 1] = Table[player2][index2] + TRIG[j - 1];
                                Eflag = 0;
                            }

                        if (STable[player2][index2] == 1) // STRx Flag2
                            TRIG[j + 1] |= 0x80;
                    }

                    TRIG[j - 5] = 0; // Clear Act
                    TRIG[j - 4] = 0;
                    TRIG[j - 3] = 0;
                    ptmp1[j4 + 1] = 0;
                    ptmp1[j4 + 0] = 0;
                    if (index1 >= 1)
                        ptmp1[j4 + 2] = 0xF0 + player1 + 1;
                    else
                        ptmp1[j4 + 2] = 0x2D;
                    if (index2 >= 1)
                        if (Eflag == 0)
                            ptmp1[j4 + 5] = 0xE0 + player2 + 1;
                        else
                            ptmp1[j4 + 5] = 0xF0 + player2 + 1;
                    else
                        ptmp1[j4 + 5] = 0;
                }
                else
                    continue;
            }

            fseek(OTRIG, i, 0);
            fwrite(TRIG, 4, 600, OTRIG);
        }
        CurSize[OWNR] += 0x970;

        if (ptmp1[0xF] == 0xFB) // Prev StartCtrig (TRIG Base -0x970)
            CurSize[OWNR] = 0;
    }

    for (int k = 0; k < 8; k++) // 2nd Loop : Patch Ctrig
    {
        fseek(PTRIG[k], 0, 2);
        Tsize = ftell(PTRIG[k]);
        for (DWORD i = 0; i < Tsize; i += 0x970)
        {
            fseek(PTRIG[k], i, 0);
            fread(STRIG, 4, 604, PTRIG[k]);
            ptmp1 = (BYTE*)STRIG;
            if (ptmp1[0x17] == 0xFE) // Label Check
            {
                //DWORD Label = STRIG[4];

                for (int j = 10; j <= 80; j += 5) // Condition Patch
                {
                    int j4 = j << 2;
                    DWORD CondID = (STRIG[j] & 0xFF000000) >> 24;
                    if (CondID == 0)
                        break;
                    else if (CondID == 0xFF) // Ctrig Condition
                    {
                        DWORD index = 0;
                        DWORD player = k;
                        DWORD Pflag = 0;

                        if ((STRIG[j + 1] & 0x40) == 0x40) // Cflag
                        {
                            index = Prohibited_Label;
                            Table[k][index] = i;
                            STRIG[j] |= 0x800000;
                        }
                        else
                        {
                            index = STRIG[j] & 0xFFFF;
                            if ((STRIG[j + 1] & 0x80) == 0x80) // Xflag
                                index += 0x10000;
                        }

                        Pflag = STRIG[j + 1] & 0xF;
                        if (Pflag > 0)
                            player = Pflag - 1;

                        if ((STRIG[j + 1] & 0x10) == 0x10) // Nflag
                            STRIG[j - 2] = EPD(Table[player][index] + 0x970) + STRIG[j - 2];
                        else
                            STRIG[j - 2] = EPD(Table[player][index]) + STRIG[j - 2];

                        if (STable[player][index] == 1) // STRx Flag
                            STRIG[j] |= 0x800000;

                        ptmp1[j4 + 4] = 0; // Clear Cond
                        ptmp1[j4 + 3] = 0xF0 + player + 1;
                        ptmp1[j4 + 0] = 0;
                        ptmp1[j4 + 1] = 0;
                    }
                    else
                        continue;
                }

                for (int j = 88; j <= 592; j += 8) // Action Patch
                {
                    int j4 = j << 2;
                    DWORD ActID = (STRIG[j] & 0xFF0000) >> 16;
                    if (ActID == 0)
                        break;
                    else if (ActID == 0x5) // Ctrig Action
                    {
                        DWORD index1 = 0, index2 = 0;
                        DWORD player1 = k, player2 = k;
                        DWORD Pflag1 = 0, Pflag2 = 0;

                        if ((STRIG[j - 4] & 0x20) == 0x20) // Cflag1
                        {
                            index1 = Prohibited_Label;
                            Table[k][index1] = i;
                            STRIG[j] |= 0x80000000;
                        }
                        else
                        {
                            index1 = STRIG[j - 5] & 0xFFFF;
                            if ((STRIG[j - 4] & 0x40) == 0x40) // Xflag1
                                index1 += 0x10000;
                        }

                        if ((STRIG[j - 3] & 0x80) == 0x80) // Cflag2
                        {
                            index2 = Prohibited_Label;
                            Table[k][index2] = i;
                            STRIG[j + 1] |= 0x80;
                        }
                        else
                        {
                            index2 = STRIG[j] & 0xFFFF;
                            if ((STRIG[j - 4] & 0x80) == 0x80) // Xflag2
                                index2 += 0x10000;
                        }

                        if (index1 >= 1) // EPD
                        {
                            Pflag1 = STRIG[j - 4] & 0xF; // Pflag1
                            if (Pflag1 > 0)
                                player1 = Pflag1 - 1;

                            if ((STRIG[j - 4] & 0x10) == 0x10) // Nflag1
                                STRIG[j - 2] = EPD(Table[player1][index1] + 0x970) + STRIG[j - 2];
                            else
                                STRIG[j - 2] = EPD(Table[player1][index1]) + STRIG[j - 2];

                            if (STable[player1][index1] == 1) // STRx Flag1
                                STRIG[j] |= 0x80000000;
                        }
                        int Eflag;
                        if (index2 >= 1)
                        {
                            Pflag2 = STRIG[j - 3] & 0xF; // Pflag2
                            if (Pflag2 > 0)
                                player2 = Pflag2 - 1;

                            if ((STRIG[j - 3] & 0x10) == 0x10) // Nflag2
                                if ((STRIG[j - 3] & 0x20) == 0x20) // Eflag2
                                {
                                    STRIG[j - 1] = EPD(Table[player2][index2] + 0x970) + STRIG[j - 1];
                                    Eflag = 1;
                                }
                                else
                                {
                                    STRIG[j - 1] = Table[player2][index2] + 0x970 + STRIG[j - 1];
                                    Eflag = 0;
                                }
                            else
                                if ((STRIG[j - 3] & 0x20) == 0x20) // Eflag2
                                {
                                    STRIG[j - 1] = EPD(Table[player2][index2]) + STRIG[j - 1];
                                    Eflag = 1;
                                }
                                else
                                {
                                    STRIG[j - 1] = Table[player2][index2] + STRIG[j - 1];
                                    Eflag = 0;
                                }

                            if (STable[player2][index2] == 1) // STRx Flag2
                                STRIG[j + 1] |= 0x80;
                        }

                        STRIG[j - 5] = 0; // Clear Act
                        STRIG[j - 4] = 0;
                        STRIG[j - 3] = 0;
                        ptmp1[j4 + 1] = 0;
                        ptmp1[j4 + 0] = 0;
                        if (index1 >= 1)
                            ptmp1[j4 + 2] = 0xF0 + player1 + 1;
                        else
                            ptmp1[j4 + 2] = 0x2D;
                        if (index2 >= 1)
                            if (Eflag == 0)
                                ptmp1[j4 + 5] = 0xE0 + player2 + 1;
                            else
                                ptmp1[j4 + 5] = 0xF0 + player2 + 1;
                        else
                            ptmp1[j4 + 5] = 0;
                    }
                    else
                        continue;
                }

                fseek(PTRIG[k], i, 0);
                fwrite(STRIG, 4, 604, PTRIG[k]);
            }
            if (STRIG[0] > 0)
                i += STRIG[0] * 0x970;
        }
    }
    
    for (int k = 0; k < 8; k++)
    {
        delete[] Table[k];
        delete[] STable[k];
    }
    for (int i = 0; i < 8; i++)
        fclose(PTRIG[i]);
    fclose(OTRIG);
   
    fclose(fout);
	return 0;
}