#pragma once

#include <Windows.h>

#define IDI_ICON1                       101

#define IDA_LISTUP						2000
#define IDA_LISTDOWN					2001
#define IDA_LISTUPX						2002
#define IDA_LISTDOWNX					2003

#define IDR_MAINMENU                      4000
#define IDR_ACCELERATOR                   4001
#define IDR_LUALICENSE                    4002
#define IDR_SCINTILLALICENSE              4003
#define IDR_BASESCRIPT                    4004
#define IDR_RCICON						  4005
#define IDR_ENCODE						  4006
#define IDR_ENCODE2						  4007
#define IDR_LOADER						  4008
#define IDR_STRCTRIG					  4009

#define IDM_EDIT_FINDREPLACE              6000
#define IDM_EDIT_FIND                     6001
#define IDM_EDIT_REPLACE                  6002
#define IDM_FILE_EXPORT                   6003
#define IDM_FILE_COMPILE                  6004
#define IDM_FILE_EXIT                     6005
#define IDM_HELP_UPDATE			          6006
#define IDM_HELP_ABOUTTRIGEDITPLUS        6007
#define IDM_EDIT_NEWTRIGGER               6008
#define IDM_HELP_LICENSES                 6009
#define IDM_VIEW_FOLDALL                  6010
#define IDM_VIEW_UNFOLDALL                6011
#define IDM_EDIT_AUTOCOMPLETE             6012
#define IDM_FILE_COMPILENONAG             6013
#define IDM_EDIT_UNLOAD					  6014
#define IDM_HELP_BLACKCAT				  6015
#define IDM_HELP_NONAME					  6016
#define IDM_HELP_EUDDB					  6017
#define IDM_EDIT_NEWDOACTS                6018
#define IDM_CTRIG_UPDATE				  6019
#define IDM_CTRIG_ABOUT					  6020
#define IDM_CTRIG_INIT					  6021
#define IDM_CTRIG_LOADER				  6022
#define IDM_CTRIG_STRCTRIG				  6023
#define IDM_CTRIG_VSCODE				  6024
